﻿<%@ Page Title="" Language="C#" MasterPageFile="~/EmpMP.Master" AutoEventWireup="true" CodeBehind="_JoiningPrediction.aspx.cs" Inherits="finalyearProject._JoiningPrediction" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>
<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
<asp:Panel ID="Panel1" runat="server">
    <!-- Start contact Area -->  
    <div id="about" class="about-area area-padding">
   <div class="container">
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="section-headline text-center">
            <h2>Candidate Joining Prediction - RF MODEL</h2>
          </div>
        </div>
      </div>
      <div class="row">
        <!-- single-well start-->
       
        <!-- single-well end-->
        <div class="col-md-6 col-sm-6 col-xs-12">
          <div class="well-middle">
            <div class="single-well">
              <a href="#">
                <h4 class="sec-head">Enter Parameters</h4>
              </a>
              
             

               

                <div class="form-group">
                <p>Enter DOJ Extended</p>

            <asp:TextBox ID="txtDOJExtended" runat="server" Width="400px" Height="30px"></asp:TextBox>
                
                    <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator1" runat="server" 
                        ControlToValidate="txtDOJExtended" ErrorMessage="Enter DOJ Extended" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                    &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator3" 
                        runat="server" ControlToValidate="txtDOJExtended" CssClass="error" 
                        ErrorMessage="Invalid" ToolTip="Invalid (1 or 0 allowed)" 
                        ValidationExpression="^[01]$" ValidationGroup="a">Invalid (1 or 0 allowed)</asp:RegularExpressionValidator>
&nbsp;<h6>DOJ Extended:Yes/No  1/0</h6>
                </div>

                
                <div class="form-group">
                <p>Enter Duration to accept offer</p>

            <asp:TextBox ID="txtAcceptOffer" runat="server" Width="400px" Height="30px"></asp:TextBox>
                
                    <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator13" runat="server" 
                        ControlToValidate="txtAcceptOffer" ErrorMessage="Enter Duration to accept offer" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                    &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator2" 
                        runat="server" ControlToValidate="txtAcceptOffer" CssClass="error" 
                        ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                        ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Duration to accept offer: numerical</h6>
                </div>

                <div class="form-group">
                 <p>Enter Notice period</p>
            <asp:TextBox ID="txtNoticeperiod" runat="server" Width="400px" 
                        Height="30px"></asp:TextBox>
                 <br />
                   
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator2" runat="server" 
                        ControlToValidate="txtNoticeperiod" ErrorMessage="Enter Notice period" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                    &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator4" 
                        runat="server" ControlToValidate="txtNoticeperiod" CssClass="error" 
                        ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                        ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Notice period: numerical</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Offered band</p>
                  <asp:TextBox ID="txtOfferedband" runat="server" Width="400px" Height="30px"></asp:TextBox>
                <br />
                   
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator3" runat="server" 
                        ControlToValidate="txtOfferedband" ErrorMessage="Enter Offered band" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>

                         &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator5" 
                         runat="server" ControlToValidate="txtOfferedband" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                         ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Offered band: E1, E2, E3, E0  1/2/3/4/5 ...</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Percent hike expected in CTC</p>
                  <asp:TextBox ID="txtPercenthike" runat="server" Width="400px" Height="30px"></asp:TextBox>
                <br />
                   
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator4" runat="server" 
                        ControlToValidate="txtPercenthike" ErrorMessage="Enter Percent hike expected in CTC" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                         &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator6" 
                         runat="server" ControlToValidate="txtPercenthike" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" 
                         ValidationExpression="^(0|[1-9]\d*)(\.\d+)?$" ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
                     &nbsp;<h6>Percent hike expected in CTC: numerical</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Percent hike offered in CTC</p>
                  <asp:TextBox ID="txtPercenthikeOffered" runat="server" Width="400px" Height="30px"></asp:TextBox>
                <br />
                   
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator5" runat="server" 
                        ControlToValidate="txtPercenthikeOffered" ErrorMessage="Enter Percent hike offered in CTC" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>

                        &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator16" 
                         runat="server" ControlToValidate="txtPercenthikeOffered" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="^(0|[1-9]\d*)(\.\d+)?$" 
                         ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Percent hike offered in CTC: numerical.</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Percent difference CTC	</p>
                  <asp:TextBox ID="txtPercentdiff" runat="server" Width="400px" Height="30px"></asp:TextBox>
                <br />
                   
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator6" runat="server" 
                        ControlToValidate="txtPercentdiff" ErrorMessage="Enter Percent difference CTC	" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>

                        <asp:RegularExpressionValidator ID="RegularExpressionValidator17" 
                         runat="server" ControlToValidate="txtPercentdiff" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" 
                         ValidationExpression="^(0|[1-9]\d*)(\.\d+)?$" ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
                     <h6>Percent difference CTC	: numerical</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Joining Bonus</p>
                  <asp:TextBox ID="txtJoiningBonus" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator7" runat="server" 
                        ControlToValidate="txtJoiningBonus" ErrorMessage="Enter Joining Bonus" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>

                        &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator9" 
                         runat="server" ControlToValidate="txtJoiningBonus" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid (1 or 0 allowed)" 
                         ValidationExpression="^[01]$" ValidationGroup="a">Invalid (1 or 0 allowed)</asp:RegularExpressionValidator>
&nbsp;<h6>Joining Bonus: No / Yes  0/1</h6>
                </div>

                <div class="form-group">
                  <p>Enter Candidate relocate actual</p>
                  <asp:TextBox ID="txtCandidaterelocateactual" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator8" runat="server" 
                        ControlToValidate="txtCandidaterelocateactual" ErrorMessage="Enter Candidate relocate actual" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>

                        &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator10" 
                        runat="server" ControlToValidate="txtCandidaterelocateactual" CssClass="error" 
                        ErrorMessage="Invalid" ToolTip="Invalid (1 or 0 allowed)" 
                        ValidationExpression="^[01]$" ValidationGroup="a">Invalid (1 or 0 allowed)</asp:RegularExpressionValidator>
&nbsp;<h6>Candidate relocate actual: No / Yes,  0/1</h6>
                </div>

               

                <div class="form-group">
                  <p>Enter Gender</p>
                  <asp:TextBox ID="txtGender" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator10" runat="server" 
                        ControlToValidate="txtGender" ErrorMessage="Enter Gender" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                        &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator1" 
                        runat="server" ControlToValidate="txtGender" CssClass="error" 
                        ErrorMessage="Invalid" ToolTip="Invalid (1 or 2 allowed)" 
                        ValidationExpression="^[12]$" ValidationGroup="a">Invalid (1 or 2 allowed)</asp:RegularExpressionValidator>
&nbsp;<h6>Gender:Male/Female, 1/2</h6>
                </div>

                <div class="form-group">
                  <p>Enter Candidate Source</p>
                  <asp:TextBox ID="txtCandidateSource" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator11" runat="server" 
                        ControlToValidate="txtCandidateSource" ErrorMessage="Enter Candidate Source" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                         <h6>Candidate Source: Direct/Employee Referral&nbsp;
                             <asp:RegularExpressionValidator ID="RegularExpressionValidator15" 
                                 runat="server" ControlToValidate="txtCandidateSource" CssClass="error" 
                                 ErrorMessage="Invalid" ToolTip="Invalid (1 or 2 or 3 allowed)" 
                                 ValidationExpression="^[123]$" ValidationGroup="a">Invalid (1 or 2 or 3 allowed)</asp:RegularExpressionValidator>
                    </h6>
                </div>

                <div class="form-group">
                  <p>Enter Rex in Yrs</p>
                  <asp:TextBox ID="txtRexinYrs" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator12" runat="server" 
                        ControlToValidate="txtRexinYrs" ErrorMessage="Enter Rex in Yrs" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                          &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator11" 
                        runat="server" ControlToValidate="txtRexinYrs" CssClass="error" 
                        ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                        ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Rex in Yrs: numerical</h6>
                </div>

                 <div class="form-group">
                  <p>Enter LOB</p>
                  <asp:TextBox ID="txtLOB" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator9" runat="server" 
                        ControlToValidate="txtLOB" ErrorMessage="Enter LOB" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                          &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator12" 
                         runat="server" ControlToValidate="txtLOB" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                         ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
                     &nbsp;<h6>LOB: ERS,INFRA,ETS,CSMP,  1/2/3/4/5...</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Location</p>
                  <asp:TextBox ID="txtLoc" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator14" runat="server" 
                        ControlToValidate="txtLoc" ErrorMessage="Enter Location" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                          &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator13" 
                         runat="server" ControlToValidate="txtLoc" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                         ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Location: Chennai, Bangalore, Noida etc.. 1/2/3/4/5....</h6>
                </div>

                 <div class="form-group">
                  <p>Enter Age</p>
                  <asp:TextBox ID="txtAge" runat="server" Width="400px" Height="30px"></asp:TextBox>
                 <br />
                    <asp:RequiredFieldValidator ID="RequiredFieldValidator15" runat="server" 
                        ControlToValidate="txtAge" ErrorMessage="Enter Age" 
                        ValidationGroup="a" CssClass="error"></asp:RequiredFieldValidator>
                          &nbsp;<asp:RegularExpressionValidator ID="RegularExpressionValidator14" 
                         runat="server" ControlToValidate="txtAge" CssClass="error" 
                         ErrorMessage="Invalid" ToolTip="Invalid" ValidationExpression="\d+" 
                         ValidationGroup="a">Invalid</asp:RegularExpressionValidator>
&nbsp;<h6>Age: numerical</h6>
                </div>

     <div>           
    <asp:Button ID="btnSubmit" runat="server" Text="Predict Candidate Joining" 
             ValidationGroup="a" onclick="btnSubmit_Click" Height="50px" 
              />
               <br />
         <br />
         <asp:Label ID="lblResult" runat="server"></asp:Label>
               <br />
         <br />
         <asp:Button ID="Button1" runat="server" Height="100px" onclick="Button1_Click" 
             Text="Send Email" Visible="False" Width="200px" />
         <br />
               </div>
             


            </div>
          </div>
        </div>
        <!-- End col-->
      </div>
    </div>
    </div>
  <!-- End Contact Area -->


    </asp:Panel>
</asp:Content>
