﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="CandidateDetails.aspx.cs" Inherits="finalyearProject.CandidateDetails" %>

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head id="Head1" runat="server">
    <title>Candidate Details</title>
</head>
<body>
    <form id="form1" runat="server">
        <div style="width: 400px; margin: 50px auto;">
            <h2>Enter Candidate Details</h2>
            <asp:Label ID="lblMessage" runat="server" ForeColor="Green"></asp:Label><br /><br />

            <asp:Label ID="Label1" Text="Name:" runat="server" /><br />
            <asp:TextBox ID="txtName" runat="server" Width="100%" /><br /><br />

            <asp:Label ID="Label2" Text="Email:" runat="server" /><br />
            <asp:TextBox ID="txtEmail" runat="server" Width="100%" /><br /><br />

            <asp:Label ID="Label3" Text="Contact:" runat="server" /><br />
            <asp:TextBox ID="txtContact" runat="server" Width="100%" /><br /><br />

            <asp:Button ID="btnSubmit" runat="server" Text="Submit" OnClick="btnSubmit_Click" />
        </div>
    </form>
</body>
</html>

