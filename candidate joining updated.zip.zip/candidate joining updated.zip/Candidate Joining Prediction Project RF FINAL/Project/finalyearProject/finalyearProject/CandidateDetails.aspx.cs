﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

namespace finalyearProject
{
    public partial class CandidateDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
                txtName.Focus();
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            string name = txtName.Text.Trim();
            string email = txtEmail.Text.Trim();
            string contact = txtContact.Text.Trim();

            // ✅ Save to DB - OPTIONAL (Add your DB logic here if needed)

            // ✅ Send email
            try
            {
                MailMessage mail = new MailMessage();
                mail.To.Add(email);
                mail.From = new MailAddress("mohitham252@gmail.com");
                mail.Subject = "Congratulations - You Can Join!";
                mail.Body = "Dear " + name + ",\n\nCongratulations! You are selected and can proceed with joining offer letter.\n\nBest regards,\nHR Team";

                SmtpClient smtp = new SmtpClient
                {
                    Host = "smtp.gmail.com",
                    Port = 587,
                    EnableSsl = true,
                    Credentials = new NetworkCredential("mohitham252@gmail.com", "jjca cwou gjne aqwr")
                };

                smtp.Send(mail);
                lblMessage.Text = "Candidate details submitted and email sent successfully!";
            }
            catch (Exception ex)
            {
                lblMessage.ForeColor = System.Drawing.Color.Red;
                lblMessage.Text = "Error: " + ex.Message;
            }
        }
    }
}