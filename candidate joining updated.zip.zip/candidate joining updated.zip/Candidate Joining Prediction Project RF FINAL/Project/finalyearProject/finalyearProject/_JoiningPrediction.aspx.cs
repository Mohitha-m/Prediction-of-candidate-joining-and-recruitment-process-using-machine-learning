﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;
using System.IO;
using System.Collections;
using System.Threading;
using System.Configuration;

namespace finalyearProject
{
    public partial class _JoiningPrediction : System.Web.UI.Page
    {
        public static OleDbConnection oledbConn;
        DataTable dt = new DataTable();
        DataTable dtDistinct = new DataTable();
        static ArrayList _arrayPatientsCnt = new ArrayList();

        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                TrainingDS();
            }
            catch
            {

            }
        }

        private void TrainingDS()
        {
            string FileName = "RTrainingDataset.xls";

            string Extension = ".xls";

            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];

            string _Location = "RTrainingDataset";

            string FilePath = Server.MapPath(FolderPath + FileName);

            ImportTrainingDS(FilePath, Extension, _Location);
        }

        private string[] loadparameters()
        {
            string[] parameters = { "P1", "P2", "P3", "P4", "P5", "P6", "P7" };

            return parameters;
        }

        double pi;
        int nc, n;
        double result;

        //function which contains the algorithm steps
        //function which contains 
        private string __RandomForest(string[] values)
        {
            ArrayList _Distance = new ArrayList();
            ArrayList _RecordId = new ArrayList();

            ArrayList s = new ArrayList();
            output.Clear();

            //try
            //{
            s = GetSubject();

            int m = 30; //k value

            //finding the distance between the objects
            for (int i = 0; i < dt.Rows.Count; i++)
            {
                double _val = 0.0;

                for (int j = 0; j < values.Length; j++)
                {
                    string _valluee = dt.Rows[i][j].ToString();

                    if (_valluee.Equals("?") || values[j].ToString().Equals("?") ||
                        _valluee.Equals("") || values[j].ToString().Equals(""))
                    {

                    }
                    else
                    {
                        _val += Math.Pow(double.Parse(dt.Rows[i][j].ToString()) - double.Parse(values[j].ToString()), 2);
                    }
                }

                _val = Math.Sqrt(_val);

                _Distance.Add(Math.Round(_val, 1));
                _RecordId.Add(i);
            }

            ArrayList temp = new ArrayList();
            ArrayList arrayRecords = new ArrayList();

            ArrayList arrayExists = new ArrayList();
            int d = 0;

            for (int x = 0; x < _Distance.Count; x++)
            {
                temp.Add(_Distance[x]);
            }

            temp.Sort();

            for (int y = 0; y < m; y++)
            {
                d = 0;

                for (int z = 0; z < _Distance.Count; z++)
                {
                    if (_Distance[z].Equals(temp[y]))
                    {
                        if (d == 0 && !arrayExists.Contains(_RecordId[z]))
                        {
                            arrayRecords.Add(_RecordId[z]);

                            arrayExists.Add(_RecordId[z]);

                            ++d;
                        }
                    }
                }
            }

            string _output = null;

            if (arrayRecords.Count > 0)
            {
                int cnt;

                ArrayList arrayCnt = new ArrayList();
                ArrayList arrayOutcome = new ArrayList();

                for (int i = 0; i < s.Count; i++)
                {
                    cnt = 0;

                    for (int j = 0; j < arrayRecords.Count; j++)
                    {
                        if (dt.Rows[int.Parse(arrayRecords[j].ToString())]["Result"].ToString().Equals(s[i]))
                        {
                            ++cnt;
                        }
                    }

                    arrayCnt.Add(cnt);
                    arrayOutcome.Add(s[i]);
                }

                ArrayList temp1 = new ArrayList();

                for (int x = 0; x < arrayCnt.Count; x++)
                {
                    temp1.Add(arrayCnt[x]);
                }

                temp1.Sort();
                temp1.Reverse();



                for (int y = 0; y < arrayCnt.Count; y++)
                {
                    if (arrayCnt[y].Equals(temp1[0]))
                    {
                        _output = s[y].ToString();

                        //if (_output.Equals("0"))
                        //{
                        //    _output = "No";
                        //}
                        //else
                        //{
                        //    _output = "Yes";
                        //}

                        return _output;

                    }
                }
            }

            return _output;
        }

        private ArrayList loadRules()
        {
            ArrayList list = new ArrayList();
            string[] parameters = { "P1", "P2", "P3", "P4", "P5", "P6", "P7" };

            return list;
        }



        private void ImportTrainingDS(string FilePath, string Extension, string _Location)
        {
            string conStr = "";

            switch (Extension)
            {
                case ".xls": //Excel 97-03

                    conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"]

                             .ConnectionString;

                    break;

                case ".xlsx": //Excel 07

                    conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"]

                              .ConnectionString;

                    break;

            }

            conStr = String.Format(conStr, FilePath, _Location);

            OleDbConnection connExcel = new OleDbConnection(conStr);

            OleDbCommand cmdExcel = new OleDbCommand();
            OleDbCommand cmdDistinct = new OleDbCommand();
            OleDbCommand cmdPatientsCnt = new OleDbCommand();

            OleDbDataAdapter oda = new OleDbDataAdapter();
            OleDbDataAdapter odaDistinct = new OleDbDataAdapter();

            cmdExcel.Connection = connExcel;
            cmdDistinct.Connection = connExcel;
            cmdPatientsCnt.Connection = connExcel;
            //Get the name of First Sheet

            connExcel.Open();

            DataTable dtExcelSchema;

            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

            connExcel.Close();

            //Read Data from First Sheet

            connExcel.Open();

            cmdExcel.CommandText = "SELECT * From [" + SheetName + "]";
            cmdDistinct.CommandText = "SELECT DISTINCT(Result) From [" + SheetName + "]";

            oda.SelectCommand = cmdExcel;
            odaDistinct.SelectCommand = cmdDistinct;

            oda.Fill(dt);
            odaDistinct.Fill(dtDistinct);

            //BLL obj = new BLL();

            if (dt.Rows.Count > 0)
            {
                if (dtDistinct.Rows.Count > 0)
                {
                    //for (int i = 0; i < dtDistinct.Rows.Count; i++)
                    //{
                    //    cmdPatientsCnt.CommandText = "SELECT COUNT(*) From [" + SheetName + "] where result=" + dtDistinct.Rows[i]["result"].ToString() + "";
                    //    _arrayPatientsCnt.Add(cmdPatientsCnt.ExecuteScalar());
                    //}
                }

                connExcel.Close();

            }
            else
            {
                ClientScript.RegisterStartupScript(this.GetType(), "Key", "<Script>alert('No Training Dataset!!!')</script>");
            }
        }



        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                string _data = txtDOJExtended.Text + "," +
                                txtAcceptOffer.Text + "," +
                                txtNoticeperiod.Text + "," +
                                txtOfferedband.Text + "," +
                                txtPercenthike.Text + "," +
                                txtPercenthikeOffered.Text + "," +
                                txtPercentdiff.Text + "," +
                                txtJoiningBonus.Text + "," +
                                txtCandidaterelocateactual.Text + "," +
                                txtGender.Text + "," +
                                txtCandidateSource.Text + "," +
                                txtRexinYrs.Text
                                + "," +
                                txtLOB.Text
                                + "," +
                                txtLoc.Text
                                + "," +
                                txtAge.Text;


                string[] values = _data.Split(',');

                string _output = __RandomForest(values);

                lblResult.ForeColor = System.Drawing.Color.Green;
                lblResult.Font.Bold = true;
                lblResult.Font.Size = 16;
                lblResult.Text = "Result: " + _output;

                if (_output.Equals("Not Joined"))
                {
                    int noticePeriod = int.Parse(txtNoticeperiod.Text.Trim());
                    double ctcDiff = double.Parse(txtPercentdiff.Text.Trim());
                    int relocate = int.Parse(txtCandidaterelocateactual.Text.Trim());
                    double experience = double.Parse(txtRexinYrs.Text.Trim());
                    int age = int.Parse(txtAge.Text.Trim());

                    if (noticePeriod > 50)
                    {
                        ShowResult("Not Joined (Notice Period > 50)", System.Drawing.Color.Red);
                        return;
                    }
                    if (ctcDiff > 20)
                    {
                        ShowResult("Not Joined (CTC Diff > 20%)", System.Drawing.Color.Red);
                        return;
                    }
                    if (relocate == 0)
                    {
                        ShowResult("Not Joined (Not willing to relocate)", System.Drawing.Color.Red);
                        return;
                    }
                    if (experience < 2)
                    {
                        ShowResult("Not Joined (Experience < 2 yrs)", System.Drawing.Color.Red);
                        return;
                    }
                    if (age > 40)
                    {
                        ShowResult("Not Joined (Age > 40)", System.Drawing.Color.Red);
                        return;
                    }

                    Button1.Visible = false;

                }
                else
                {
                    Button1.Visible = true;
                }

            }
            catch
            {

            }
        }

        private void ShowResult(string message, System.Drawing.Color color)
        {
            lblResult.Text = "Result: " + message;
            lblResult.ForeColor = color;
            lblResult.Font.Bold = true;
            lblResult.Font.Size = 16;
        }

        ArrayList output = new ArrayList();
        ArrayList mul = new ArrayList();

        //function to load subject
        public ArrayList GetSubject()
        {

            ArrayList s = new ArrayList();

            if (dtDistinct.Rows.Count > 0)
            {
                s.Clear();

                for (int i = 0; i < dtDistinct.Rows.Count; i++)
                {
                    if (dtDistinct.Rows[i]["Result"].Equals(""))
                    {
                    }
                    else
                    {
                        s.Add(dtDistinct.Rows[i]["Result"].ToString());
                    }
                }
            }

            return s;

        }


   

        //function to get distinct values of a specific parameter
        private ArrayList _DistinctValuesofSP(string parameter)
        {
            string FileName = "RTrainingDataset.xls";

            string Extension = ".xls";

            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];

            string _Location = "RTrainingDataset";

            string FilePath = Server.MapPath(FolderPath + FileName);

            ArrayList _AValues = new ArrayList();

            _AValues = _DistinctValuesofSPImport(FilePath, Extension, _Location, parameter);

            return _AValues;
        }

        private ArrayList _DistinctValuesofSPImport(string FilePath, string Extension, string _Location, string parameter)
        {
            string conStr = "";

            switch (Extension)
            {
                case ".xls": //Excel 97-03

                    conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"]

                             .ConnectionString;

                    break;

                case ".xlsx": //Excel 07

                    conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"]

                              .ConnectionString;

                    break;

            }

            conStr = String.Format(conStr, FilePath, _Location);

            OleDbConnection connExcel = new OleDbConnection(conStr);
            OleDbCommand cmdExcel = new OleDbCommand();
            OleDbDataAdapter oda = new OleDbDataAdapter();
            DataTable tabDValues = new DataTable();
            ArrayList _arrayValues = new ArrayList();

            cmdExcel.Connection = connExcel;

            connExcel.Open();

            DataTable dtExcelSchema;

            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

            connExcel.Close();

            //Read Data from First Sheet

            connExcel.Open();

            cmdExcel.CommandText = "SELECT DISTINCT(" + parameter + ") From [" + SheetName + "]";

            oda.SelectCommand = cmdExcel;
            oda.Fill(tabDValues);

            if (tabDValues.Rows.Count > 0)
            {
                for (int i = 0; i < tabDValues.Rows.Count; i++)
                {
                    _arrayValues.Add(tabDValues.Rows[i]["" + parameter + ""]);
                }
            }

            connExcel.Close();

            return _arrayValues;
        }

        //function which contains the algorithm steps
        private string _RandomForestAlgorithm()
        {
            ArrayList s = new ArrayList();
            ArrayList _aValues = new ArrayList();

            ArrayList _rules = new ArrayList();

            string _outcomeCondition = null;

            //try
            //{
            s.Add("0");
            s.Add("1");
            s.Add("2");
            s.Add("3");

            string[] parameters = loadparameters();

            //finding gini slpit
            for (int i = 0; i < parameters.Length; i++)
            {
                //get parameter distinct values
                _aValues = _DistinctValuesofSP(parameters[i]);

                ArrayList _arrayGSplit = new ArrayList();

                //now find g1, g2 and g split
                for (int j = 0; j < _aValues.Count; j++)
                {
                    //finding number of 0's and 1's based on the parameter value
                    double _cntOutComeX_P_1 = 0;
                    double _cntOutComeY_P_1 = 0;
                    double _CntOutcome_P_1 = 0;
                    // _cntOutComeX_P_1 = _outcomeCnt(parameters[i], "<=", double.Parse(_aValues[j].ToString()), int.Parse(s[0].ToString()));
                    // _cntOutComeY_P_1 = _outcomeCnt(parameters[i], "<=", double.Parse(_aValues[j].ToString()), int.Parse(s[1].ToString()));                                        
                    // _CntOutcome_P_1 = _cntOutComeX_P_1 + _cntOutComeY_P_1;

                    for (int k = 0; k < s.Count; k++)
                    {
                        _cntOutComeX_P_1 += _outcomeCnt(parameters[i], "<=", double.Parse(_aValues[j].ToString()), int.Parse(s[k].ToString()));
                    }

                    _CntOutcome_P_1 = _cntOutComeX_P_1;

                    double _cntOutComeX_P_2 = 0;
                    double _cntOutComeY_P_2 = 0;
                    double _CntOutcome_P_2 = 0;

                    // _cntOutComeX_P_2 = _outcomeCnt(parameters[i], ">", double.Parse(_aValues[j].ToString()), int.Parse(s[0].ToString()));
                    //_cntOutComeY_P_2 = _outcomeCnt(parameters[i], ">", double.Parse(_aValues[j].ToString()), int.Parse(s[1].ToString()));
                    // _CntOutcome_P_2 = _cntOutComeX_P_2 + _cntOutComeY_P_2;

                    for (int k = 0; k < s.Count; k++)
                    {
                        _cntOutComeX_P_2 += _outcomeCnt(parameters[i], ">", double.Parse(_aValues[j].ToString()), int.Parse(s[k].ToString()));
                    }

                    _CntOutcome_P_2 = _cntOutComeX_P_2;

                    //finding g1, g2 and g split
                    double g1 = 0;
                    double g2 = 0;
                    double gSplit = 0;
                    double _totalOutCome = 0;
                    _totalOutCome = _CntOutcome_P_1 + _CntOutcome_P_2;

                    g1 = 1 - (Math.Pow((_cntOutComeX_P_1 / _CntOutcome_P_1), 2) + Math.Pow((_cntOutComeY_P_1 / _CntOutcome_P_1), 2));

                    double _cal = Math.Pow((_cntOutComeX_P_2 / _CntOutcome_P_2), 2) + Math.Pow((_cntOutComeY_P_2 / _CntOutcome_P_2), 2);

                    if (double.IsNaN(g1))
                    {
                        g1 = 1;
                    }

                    g2 = 1 - _cal;

                    if (double.IsNaN(g2))
                    {
                        g2 = 1;
                    }

                    gSplit = (_CntOutcome_P_1 / _totalOutCome) * g1 + (_CntOutcome_P_2 / _totalOutCome) * g2;

                    _arrayGSplit.Add(gSplit);
                }

                //0.40
                // 0.26
                // 0.46
                // 0.30
                // 0.48

                //so we got all gini split for the parameter, now identify least number.
                ArrayList _leastTemp = new ArrayList();

                for (int k = 0; k < _arrayGSplit.Count; k++)
                {
                    _leastTemp.Add(_arrayGSplit[k]);
                }

                _leastTemp.Sort();

                double _bestSplit = 0;

                for (int x = 0; x < _arrayGSplit.Count; x++)
                {
                    if (_arrayGSplit[x].Equals(_leastTemp[0]))
                    {
                        //got least number (least split)
                        string _leastSplit = _aValues[x].ToString();

                        _bestSplit = (double.Parse(_leastSplit) + double.Parse(_aValues[x + 1].ToString())) / 2;

                    }
                }

                //find the count of 0's and 1's for the best split value
                //double _BSplitX_1 = _outcomeCnt(parameters[i], "<=", _bestSplit, int.Parse(s[0].ToString()));
                //double _BSplitY_1 = _outcomeCnt(parameters[i], "<=", _bestSplit, int.Parse(s[1].ToString()));

                double _BSplitX_1 = 0;

                for (int k = 0; k < s.Count; k++)
                {
                    _BSplitX_1 += _outcomeCnt(parameters[i], "<=", _bestSplit, int.Parse(s[k].ToString()));
                }

                //double _BSplitX_2 = _outcomeCnt(parameters[i], ">", _bestSplit, int.Parse(s[0].ToString()));
                //double _BSplitY_2 = _outcomeCnt(parameters[i], ">", _bestSplit, int.Parse(s[1].ToString()));

                double _BSplitX_2 = 0;

                for (int k = 0; k < s.Count; k++)
                {
                    _BSplitX_2 += _outcomeCnt(parameters[i], ">", _bestSplit, int.Parse(s[k].ToString()));
                }

                //generating rules
                //if (_BSplitX_1 > _BSplitY_1)
                //{
                //    _rules.Add(parameters[i] + "<=" + _bestSplit + "-" + "result_" + s[0]);
                //    _outcomeCondition += "P" + (i + 1) + "<=" + _bestSplit + ",";
                //}
                //else
                //{
                //    _rules.Add(parameters[i] + "<=" + _bestSplit + "-" + "result_" + s[1]);
                //}

                //if (_BSplitX_2 > _BSplitY_2)
                //{
                //    _rules.Add(parameters[i] + ">" + _bestSplit + "-" + "result_" + s[0]);
                //    _outcomeCondition += "P" + (i + 1) + "<=" + _bestSplit + ",";
                //}
                //else
                //{
                //    _rules.Add(parameters[i] + ">" + _bestSplit + "-" + "result_" + s[1]);
                //}

                _rules = loadRules();

            }

            return _outcomeCondition;
        }

        //function to get number of 0's and 1's based on parameter value
        private int _outcomeCnt(string parameter, string op, double parameterValue, int outcome)
        {
            string FileName = "TrainingDataset.xls";

            string Extension = ".xls";

            string FolderPath = ConfigurationManager.AppSettings["FolderPath"];

            string _Location = "TrainingDataset";

            string FilePath = Server.MapPath(FolderPath + FileName);

            int _cnt = 0;

            _cnt = __outcomeCntImport(FilePath, Extension, _Location, parameter, op, parameterValue, outcome);

            return _cnt;
        }

        private int __outcomeCntImport(string FilePath, string Extension, string _Location, string parameter, string op, double parameterValue, int outcome)
        {
            string conStr = "";

            switch (Extension)
            {
                case ".xls": //Excel 97-03

                    conStr = ConfigurationManager.ConnectionStrings["Excel03ConString"]

                             .ConnectionString;

                    break;

                case ".xlsx": //Excel 07

                    conStr = ConfigurationManager.ConnectionStrings["Excel07ConString"]

                              .ConnectionString;

                    break;

            }

            conStr = String.Format(conStr, FilePath, _Location);

            OleDbConnection connExcel = new OleDbConnection(conStr);
            OleDbCommand cmdExcel = new OleDbCommand();
            OleDbDataAdapter oda = new OleDbDataAdapter();
            DataTable tabDValues = new DataTable();
            ArrayList _arrayValues = new ArrayList();

            cmdExcel.Connection = connExcel;

            connExcel.Open();

            DataTable dtExcelSchema;

            dtExcelSchema = connExcel.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, null);

            string SheetName = dtExcelSchema.Rows[0]["TABLE_NAME"].ToString();

            connExcel.Close();

            //Read Data from First Sheet

            connExcel.Open();

            cmdExcel.CommandText = "SELECT COUNT(*) From [" + SheetName + "] WHERE " + parameter + op + parameterValue + " AND Result= " + outcome + "";
            int _Cnt = int.Parse(cmdExcel.ExecuteScalar().ToString());

            connExcel.Close();

            return _Cnt;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("CandidateDetails.aspx");
        }
       
             
    }
}